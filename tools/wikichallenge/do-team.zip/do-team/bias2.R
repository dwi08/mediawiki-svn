# "bias2.R" generates predictions for users, who made no revisions in the last 22 weeks of the training data.
# 
# The object "revs" is a list of 486 elements, representing the 486 weeks in which revisions were made.
# Each element is a dataframe with the three columns "user_id", "edits", and "timestamp". "edits" means the number of revisions that a particular author makes in the respective week.
# 
# From the list "revs" is generated a dataframe "r", consisting of 487 columns; the first column for the user_id, the remaining columns for the number of revisions a user makes in the corresponding week.
# 
# "first_week" contains the week number of the user's first revision.
# 
# The function "wg.edits" counts for all users, who made some revisions in the week "letzte.woche" and no revisions in the "abstinenz" weeks after week "letzte.woche", how many revisions are made in the "wochen.spaeter" weeks thereafter.
# 
# "ws" is a list of 28 elements, the first element containing data of users who were active in a particular week and inactive for the following 22 weeks or longer, the last element containing data for users who were active in a particular week and inactive for the following 49 weeks or longer.
# Each element contains then the mean log number of revisions in the two weeks thereafter, three weeks thereafter, and so on (but in reverse order).
# 
# Since the number of edits seems to be roughly proportional to the number of weeks, a slope is calculated. This slope is used to estimate the log number of edits for the following 22 weeks. This is done for each element of "ws". 
# From 22 weeks abstinence to 40 weeks abstinence the log number of revisions thereafter is roughly linearly declining. For users who are 41 weeks or longer inactive, a log number of revisions of 0.16 is assumed.
# These estimates are saved in the object "pliste.a".
# 
# For users who were active in the last 31 weeks, but not in the last 22 weeks, the number of their revisions are estimated by a linear model, learned on users, who were active in the interval from week 435 to week 442 and were inactive from week 443 to week 464.
# 
# The regression model has three influence variables: total number of revisions, number of revisions in the last two weeks, and wether the user has a personal page or not (1 or 0). Response variable is the number of revisions in the 22 weeks from week 465 to week 486.
# 
# The predictions, together with the predictions for users who were inactive in the last 31 weeks are saved in the object "pliste.neu" and the file "pausierer_neu.RData".# https://tssrv.wiso.uni-dortmund.de/wc/wiki/index.php/Hauptseite
library(RODBC) #Paket laden

wikidata <- odbcConnect(dsn="wikidata") #Verbindung zur Datenbank 

unterteilung <- 86400*7#*4.5

betrachteterZeitraum <- 1:486 # Beispiel 52 Intervalle

start.datum <- strptime("2001-05-09", "%Y-%m-%d")

ende.datum <- strptime("2010-08-31", "%Y-%m-%d")

anzahl_shifts <- as.integer(ceiling(difftime(ende.datum, start.datum, units = "secs")/unterteilung))

get_command <- function(start.datum, ende.datum){
	paste(
		"SELECT user_id, COUNT(*) AS edits, timestamp ", 
		"FROM wcraw.training ",
		"WHERE timestamp >= '", start.datum + (unterteilung)*(i-1) , "' AND timestamp < '", start.datum + (unterteilung)*(i),
		"' GROUP BY user_id ORDER BY timestamp", sep = "")
}

if (is.character(betrachteterZeitraum) && betrachteterZeitraum == "MAX"){
	betrachteterZeitraum <- 1:anzahl_shifts
}

revs <- vector("list", length(betrachteterZeitraum))

for (i in betrachteterZeitraum) {
	revs[[i]] <- sqlQuery(wikidata, get_command(start.datum, ende.datum))
}

close(wikidata) #Verbindung zur Datenbank wieder schlie�en

user_id <- NULL
for (j in 1:length(revs)){ 
  user_id <- unique(c(user_id, revs[[j]]$user_id))
}

r <- revs[[1]][,1:2]
names(r)[2] <- "w1"
for (j in 2:length(revs)){
  r <- merge(r, revs[[j]][,1:2], by="user_id", all=TRUE)
  names(r)[j+1] <- paste("w", j, sep="")
}
r[is.na(r)] <- 0

first.week <- numeric(nrow(r)) # In welcher Woche war der User erstmals aktiv?
for (j in 1:nrow(r)){
  first.week[j] <- min((2:487)[r[j,-1]>0])
}
r[,8] <- as.numeric(r[,8]) # in der achten Spalte sind die Nullen vom Typ character

n.user <- nrow(r)
n.weeks <- ncol(r) - 1

wg.edits <- function(r, letzte.woche, abstinenz, wochen.spaeter){
  if (letzte.woche + wochen.spaeter + abstinenz > 486)
    return("Achtung! Verlasse gueltigen Wochenbereich!")
  v.letzte.woche <- r[(1:n.user), letzte.woche+1] != rep(0, n.user)
  v.abstinenz <- rowSums(r[(1:n.user), (letzte.woche+2):(letzte.woche+1+abstinenz)]) == rep(0, n.user)
  anzahl.edits <- rowSums(r[v.letzte.woche & v.abstinenz,(letzte.woche+abstinenz+2):(letzte.woche+abstinenz+wochen.spaeter+1)])
  return(anzahl.edits) 
}

max.woche <- 486

ws <- index <- lm1 <- steigung <- list(28)
for (k in 1:28){
  abstinenz <- 21+k
  ws[[k]] <- numeric(52-abstinenz-2)
for (j in 1:(52-abstinenz-2)){ 
  wochen.spaeter <- 52-abstinenz-j
  letzte.woche <- 434
  wg <- log.wg <- list(max.woche-letzte.woche-abstinenz-wochen.spaeter)
  for (i in 1:(max.woche-letzte.woche-abstinenz-wochen.spaeter)){
    wg[[i]] <- wg.edits(r, letzte.woche+i, abstinenz, wochen.spaeter)
    log.wg[[i]] <- exp(mean(log(wg[[i]]+1)))-1
  }
  ws[[k]][j] <- mean(unlist(log.wg))
}

index[[k]] <- 52-abstinenz-(1:length(ws[[k]]))
plot(index[[k]], ws[[k]])

lm1[[k]] <- lm(ws[[k]]~index[[k]]-1)
steigung[[k]] <- coefficients(lm1[[k]]) 
abline(0, steigung[[k]])
}

edpause <- unlist(steigung)*22
wpause <- 21+(1:28)
plot(wpause, edpause)
lmst <- lm(edpause[1:20]~wpause[1:20])
stpause <- coefficients(lmst) 
abline(stpause[1], stpause[2])

p.user <- function(r, letzte.woche, abstinenz, edits){
  if (letzte.woche + abstinenz > 486)
    return("Achtung! Verlasse gueltigen Wochenbereich!")

  v.letzte.woche <- r[(1:n.user), letzte.woche+1] != rep(0, n.user)
  v.abstinenz <- rowSums(r[(1:n.user), (letzte.woche+2):(letzte.woche+1+abstinenz)]) == rep(0, n.user)
  pedits <- cbind(r[v.letzte.woche & v.abstinenz, 1], edits)
  return(pedits) 
}

letzte.woche <- 465
abstinenz <- 22

pliste <- NULL  # user_ids who were inactive in the last 22 weeks, 2nd col: predicted edits
for (j in (1:19)){
  edits <- stpause[1]+wpause[j]*stpause[2]
  pliste <- rbind(pliste, p.user(r, 465-j, 21+j, edits))
}
for (j in (20:31)){
  edits <- 0.16 # abstinenz > 40 -> 0.16
  pliste <- rbind(pliste, p.user(r, 465-j, 21+j, edits))
}
pliste.a <- pliste

fl.user <- function(r, letzte.woche, abstinenz, flday){
  if (letzte.woche + abstinenz > 486)
    return("Achtung! Verlasse gueltigen Wochenbereich!")
  v.letzte.woche <- r[(1:n.user), letzte.woche+1] != rep(0, n.user)
  v.abstinenz <- rowSums(r[(1:n.user), (letzte.woche+2):(letzte.woche+1+abstinenz)]) == rep(0, n.user)
  pedits <- r[v.letzte.woche & v.abstinenz, 1]
  return(r[which(flday %in% pedits), 1]) 
}
lastday.user <- revs[[465]][1:1451, 1]
firstday.user <- revs[[434]][3404:3751, 1]
f.user <- fl.user(r, 434, 23, firstday.user)
l.user <- fl.user(r, 465, 21, lastday.user)

last.pliste <- cbind(l.user, stpause[1]+wpause[1]*stpause[2])
first.pliste <- cbind(f.user, 0.22)
p.liste.a2 <- rbind(pliste.a, first.pliste, last.pliste)

pliste <- NULL  # user_ids who were inactive in the last 22 weeks; 2nd col: predicted edits
for (j in (1:8)){
  edits <- stpause[1]+wpause[j]*stpause[2]
  pliste <- rbind(pliste, p.user(r, 443-j, 21+j, edits))
}
pliste.b <- pliste
pliste.b.true <- cbind(r[r[,1] %in% pliste.b[,1], 1], log(rowSums(r[ r[,1] %in% pliste.b[,1], 465:486]) + 1))
pliste.b <- pliste.b[order(pliste.b[,1]),]
pliste.b.true <- pliste.b.true[order(pliste.b.true[,1]),]
pdata <- r[(rowSums(r[, 466:487]) == rep(0, n.user)) | r[,1] %in% f.user | r[,1] %in% l.user,]
ziel <- log(rowSums(pdata[,458:465])+1)
pfirst <- first.week[((rowSums(r[, 466:487]) == rep(0, n.user)) | r[,1] %in% f.user | r[,1] %in% l.user)]

wikidata <- odbcConnect(dsn="wikidata") #Verbindung zur Datenbank 
dataa <- sqlQuery(wikidata, paste("SELECT * FROM wc.einfluss_", "a", sep=""))
dataa2 <- dataa[, c("user_id","days_between_first_previous","days_since_previous","has_userpage")]
close(wikidata) #Verbindung zur Datenbank wieder schlie�en

dataa2 <- dataa2[order(dataa2[,1]),]
dataa3 <- dataa2[(rowSums(r[, 466:487]) == rep(0, n.user)) | r[,1] %in% f.user | r[,1] %in% l.user,]
ges.edits <- log(rowSums(pdata[,2:457])+1)
edits.435.457 <- log(rowSums(pdata[,435:457])+1)
pdata2 <- cbind(pfirst, dataa3[,2:4], ges.edits, edits.435.457)

lmpg <- glm(ziel~., data=pdata2[,], family=gaussian)
lmpp <- glm(ziel~., data=pdata2[,], family=poisson)
lmp <- glm(ziel~., data=pdata2[,])
summary(lmp) 
(pcoeff <- lmp$coefficients)
ppcoeff <- lmpp$coefficients
predp <- pcoeff[1] + pcoeff[2]*pdata2[,1] + pcoeff[3]*pdata2[,2] + pcoeff[4]*pdata2[,4] + pcoeff[5]*pdata2[,5] + pcoeff[6]*pdata2[,6]
lambda <- ppcoeff[1] + ppcoeff[2]*pdata2[,1] + ppcoeff[3]*pdata2[,2] + ppcoeff[4]*pdata2[,3] + ppcoeff[5]*pdata2[,4] + ppcoeff[6]*pdata2[,5] + ppcoeff[6]*pdata2[,6]
predpp <- exp(lambda)


pausierer <- (rowSums(r[, 466:487]) == rep(0, n.user)) | r[,1] %in% f.user | r[,1] %in% l.user
p5 <- (rowSums(r[, 458:487]) == rep(0, n.user)) | r[,1] %in% f.user
p67 <- (pausierer & !(rowSums(r[, 458:487]) == rep(0, n.user)))

vergl67 <- (rowSums(r[, 444:465]) == rep(0, n.user)) & !(rowSums(r[, 436:443]) == rep(0, n.user))
ziel67 <- log(rowSums(r[vergl67,467:487])+1)

pfirst67 <- first.week
ges.edits67 <- log(rowSums(r[,2:465])+1)
edits.letzte2wochen.vgl67 <- log(rowSums(r[,436:443])+1)
edits.letzte2wochen.p67 <- log(rowSums(r[,458:487])+1)
datap67 <- data.frame( ges.edits67, edits2w=edits.letzte2wochen.p67, dataa2[,4]) # ohne pfirst67,

data67 <- data.frame( ges.edits67, edits2w=edits.letzte2wochen.vgl67, dataa2[,4]) # ohne pfirst67,

lmp67 <- glm(ziel67~., data=data67[vergl67,])
pred67 <- predict(object=lmp67, newdata=datap67[p67,])
pred67 <- apply(cbind(0, pred67), 1, max)
pliste.neu <- rbind(pliste.a[!(pliste.a[,1] %in% r[p67,1]),], cbind(r[p67, 1], pred67))
save(pliste.neu, file="pausierer_neu.RData")
