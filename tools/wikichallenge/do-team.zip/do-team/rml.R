library(RODBC)
library(MASS)

source("datenvorverarbeitung.R")
####load data:
wikidata <- odbcConnect(dsn="wikidata")
#get user_ids
einfluss <- sqlQuery(wikidata, paste("SELECT * FROM wc.einfluss_", "a", sep=""))
user_ids <- einfluss$user_id

#data preprocessing:
dataa.list <- datenvorverarbeitung2(einfluss_zeitraum="a", 
                verwende=paste("number_edits_", 1:12 ,"w",sep=""), 
                                  verwende_nicht=NULL)

datab.list <-datenvorverarbeitung2(einfluss_zeitraum="b", 
                verwende=paste("number_edits_", 1:12 ,"w",sep=""), 
                                  verwende_nicht=NULL)


datac.list <-datenvorverarbeitung2(einfluss_zeitraum="c", 
                verwende=paste("number_edits_", 1:12 ,"w",sep=""), 
                                  verwende_nicht=NULL)

###get variables with information of the last 12 weeks
weeks.a <- dataa.list$data[paste("number_edits_", 1:12 ,"w",sep="")]
weeks.b <- datab.list$data[paste("number_edits_", 1:12 ,"w",sep="")]
weeks.c <- datac.list$data[paste("number_edits_", 1:12 ,"w",sep="")]


weeks.ind <- 1:12

#input: vector of number of edits per week for one person 
#output: slope of robust regression (rlm) of the first order linear model
#with intercept using the week number as the only variable
rlm.coef <- function(ts.oneuser){
    if(sum(ts.oneuser)==0) return(0)
    df <- data.frame(ts.oneuser, week=weeks.ind)
    names(df)[1]<- "nedits"
    mod <- rlm(nedits~week, data=df)
    mod$coefficients["week"]
} 



#apply rlm.coef to all users on all data sets
system.time(coefa <- apply(weeks.a, 1, function(ts.oneuser) rlm.coef(ts.oneuser)))
system.time(coefb <- apply(weeks.b, 1, function(ts.oneuser) rlm.coef(ts.oneuser)))
system.time(coefc <- apply(weeks.c, 1, function(ts.oneuser) rlm.coef(ts.oneuser)))

#truncate
coefa[coefa>5]<-5
coefa[coefa< -5]<- -5
coefb[coefb>5]<-5
coefb[coefb< -5]<- -5
coefc[coefc>5]<-5
coefc[coefc< -5]<- -5

#Get ids of the "active" users for each data set.
# "active" is defined by positive number of edits 
# in the last five months of the coresponding time period  
all.active.usersa.rlm <- dataa.list$data.user_id
all.active.usersb.rlm <- datab.list$data.user_id
all.active.usersc.rlm <- datac.list$data.user_id

# for each user:
# if(nonactive) return(0)
#else return(corresponding_rlm_score)

edittrend_rml.a <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersa.rlm)) return(0)
    else{
        id.pos <- which(all.active.usersa.rlm==user_id)
        return(coefa[id.pos])
    }
    
})

edittrend_rml.b <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersb.rlm)) return(0)
    else{
        id.pos <- which(all.active.usersb.rlm==user_id)
        return(coefb[id.pos])
    }
    
})

edittrend_rml.c <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersc.rlm)) return(0)
    else{
        id.pos <- which(all.active.usersc.rlm==user_id)
        return(coefc[id.pos])
    }
    
})


#save
save(edittrend_rml.a, edittrend_rml.b, edittrend_rml.c, file="edittrend_rml.RData")
