setwd("//store/schulze/wikichallenge/Repo/scripts")
##Vor jedem Zugriff in R:
library(RODBC) #Paket laden

wikidata <- odbcConnect(dsn="wikidata") #Verbindung zur Datenbank 

# Konstanten
# Unterteilung der Intervalle
unterteilung <- 86400*7#*4.5

# Betrachteter Zeitraum
#betrachteterZeitraum <- 100:105 # Beispiel 5 Intervalle
betrachteterZeitraum <- 1:157 # Beispiel 157 Intervalle
#betrachteterZeitraum <- "MAX" # Alle Daten

#--------------------------------------------

# Datum des ersten Eintrags
start.datum <- strptime("2007-09-01", "%Y-%m-%d")

# Datum des letzten Eintrags
ende.datum <- strptime("2010-08-31", "%Y-%m-%d")

#--------------------------------------------

#Anzahl der Shifts in Wochen
anzahl_shifts <- as.integer(ceiling(difftime(ende.datum, start.datum, units = "secs")/unterteilung))

#MySQL Befehl-Ausgabe
get_command <- function(start.datum, ende.datum){
	paste(
		"SELECT COUNT(*) AS edits ", 
		"FROM wcraw.training ",
		"WHERE timestamp >= '", start.datum + (unterteilung)*(i-1) , "' AND timestamp < '", start.datum + (unterteilung)*(i),
		"'", sep = "")
}

# Wenn Zeitraum MAX gew�hlt, so werden alle Daten ausgegeben
if (is.character(betrachteterZeitraum) && betrachteterZeitraum == "MAX"){
	betrachteterZeitraum <- 1:anzahl_shifts
}

# Initialisiere Vektor f�r die Editierungs-Intervalle
revs <- vector("list", length(betrachteterZeitraum))

for (i in betrachteterZeitraum) {
	#print(get_command(start.datum, ende.datum))
	revs[[i]] <- sqlQuery(wikidata, get_command(start.datum, ende.datum))
#	print(revs[[i]])
}

close(wikidata) #Verbindung zur Datenbank wieder schlie�en

# Berechnet f�r jeden Zeitraum die Anzahl der Edits in einem Vektor
# (wie "unlist(revs)")
anzahlEdits <- rep(NA, length(betrachteterZeitraum))
for (i in (1:length(betrachteterZeitraum))){
	if (length(revs[[i+betrachteterZeitraum[1]-1]]$edits)==0 || is.na(revs[[i+betrachteterZeitraum[1]-1]]$edits))
	{
		anzahlEdits[i] <- 0
	}
	else
	{
		anzahlEdits[i] <- sum(revs[[i+betrachteterZeitraum[1]-1]]$edits)
	}
}

#save(revs, file="revs.RData")
#load("revs.RData")
plot(betrachteterZeitraum, anzahlEdits, type ="l", ylim=c(0,max(anzahlEdits)))

# Liste aller user_ids erstellen
user_id <- NULL
for (j in 1:length(revs)){ 
  user_id <- unique(c(user_id, revs[[j]]$user_id))
}


zahlvonedits <- function(woche){
  user.edits <- numeric(length(user_id))
  for (j in 1:nrow(revs[[woche]])){
    user.edits[user_id == revs[[woche]]$user_id[j]] <- revs[[woche]][j, 2]
  }
  return(user.edits)
} 

system.time(wochen.edits <- sapply(1:length(revs), zahlvonedits))
#save(wochen.edits, file="wochenedits.RData")
#load("wochenedits.RData")

gesamt.edits[j] <- sum(wochen.edits

(m1 <- merge(user_id, revs[[1]], by.y = "user_id"))
