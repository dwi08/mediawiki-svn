datenvorverarbeitung <- function(einfluss_zeitraum="b", ziel_zeitraum=NULL, verwende=NULL, verwende_nicht=NULL, schaetze.pausierer=0){
  einfluss <- sqlQuery(wikidata, paste("SELECT * FROM wc.einfluss_", einfluss_zeitraum, sep=""))
  if(!is.null(ziel_zeitraum)) ziel <- sqlQuery(wikidata, paste("SELECT * FROM wc.ziel_", ziel_zeitraum, sep="")) 
 
  load("edittime_gini.RData")
  edittime_gini <- get(paste("edittime_gini", einfluss_zeitraum, sep="."))
  
  load("edittrend_rml.RData")
  edittrend_rml <- get(paste("edittrend_rml", einfluss_zeitraum, sep="."))
  einfluss <- data.frame(einfluss, edittrend_rml=edittrend_rml)
  
  keepNA_1 <- is.na(einfluss[,"days_between_first_previous"])
  einfluss[is.na(einfluss)] <- 0
  einfluss[,"days_between_first_previous"][keepNA_1] <- NA 
  
  einfluss <- transform(einfluss,
    number_edits_5to2m=number_edits_5m-number_edits_2m,
    number_edits_12to5m=number_edits_12m-number_edits_5m,
    proportion_edits_article_5m=number_edits_article_5m/number_edits_5m,
    proportion_edits_articletalk_5m=number_edits_articletalk_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_user_5m=number_edits_user_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_usertalk_5m=number_edits_usertalk_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_wikipediaboth_5m=number_edits_wikipediaboth_5m/(number_edits_5m-number_edits_article_5m),
    proportion_articles_edits_5m=number_articles_5m/number_edits_5m,
    proportion_selfreverts_5m=number_selfreverts_5m/number_edits_5m,
    proportion_externalreverts_5m=number_externalreverts_5m/number_edits_5m,
    proportion_revertedbyothers_5m=number_revertedbyothers_5m/number_edits_5m,
    proportion_extent_deletion_5m=number_extent_deletion_5m/number_edits_5m,
    proportion_extent_word_5m=number_extent_word_5m/number_edits_5m,
    proportion_extent_sentence_5m=number_extent_sentence_5m/number_edits_5m,
    proportion_extent_paragraph_5m=number_extent_paragraph_5m/number_edits_5m,
    proportion_realcomments_5m=number_realcomments_5m/number_edits_5m
  )
True <- function(x, cond, na.false=TRUE){
  result <- ifelse(eval(parse(text=cond)), TRUE, FALSE)
  if(na.false) result[is.na(result)] <- FALSE
  result <- factor(result, levels=c(TRUE, FALSE))
  return(result)
}

  einfluss <- transform(einfluss,
    proportion_edits_article_5m.1zero=True(proportion_edits_article_5m, "x==0"),
    proportion_edits_article_5m.2low=True(proportion_edits_article_5m, "x>0 & x<=0.7"),
    proportion_edits_article_5m.3high=True(proportion_edits_article_5m, "x>0.7 & x<1"),

    proportion_edits_articletalk_5m.1zero=True(proportion_edits_articletalk_5m, "x==0"),
    proportion_edits_articletalk_5m.2low=True(proportion_edits_articletalk_5m, "x>0 & x<=0.3"),
    proportion_edits_articletalk_5m.3high=True(proportion_edits_articletalk_5m, "x>0.3 & x<1"),

    proportion_edits_user_5m.1zero=True(proportion_edits_user_5m, "x==0"),
    proportion_edits_user_5m.2low=True(proportion_edits_user_5m, "x>0 & x<=0.2"),
    proportion_edits_user_5m.3high=True(proportion_edits_user_5m, "x>0.2 & x<1"),

    proportion_edits_usertalk_5m.1zero=True(proportion_edits_usertalk_5m, "x==0"),
    proportion_edits_usertalk_5m.2low=True(proportion_edits_usertalk_5m, "x>0 & x<=0.3"),
    proportion_edits_usertalk_5m.3high=True(proportion_edits_usertalk_5m, "x>0.3 & x< 1"),

    proportion_edits_wikipediaboth_5m.1zero=True(proportion_edits_wikipediaboth_5m, "x==0"),
    proportion_edits_wikipediaboth_5m.2low=True(proportion_edits_wikipediaboth_5m, "x>0 & x<=0.3"),
    proportion_edits_wikipediaboth_5m.3high=True(proportion_edits_wikipediaboth_5m, "x>0.3 & x< 1"),

    proportion_articles_edits_5m.1low=True(proportion_articles_edits_5m, "x>0 & x<=0.3"),
    proportion_articles_edits_5m.2high=True(proportion_articles_edits_5m, "x>0.3 & x<1"),

    number_usertalkpages_5m.1many=True(number_usertalkpages_5m, "x>2"),

    proportion_selfreverts_5m.1zero=True(proportion_selfreverts_5m, "x==0"),
    proportion_selfreverts_5m.2low=True(proportion_selfreverts_5m, "x>0 & x<=0.03"),

    proportion_externalreverts_5m.1zero=True(proportion_externalreverts_5m, "x==0"),
    proportion_externalreverts_5m.2low=True(proportion_externalreverts_5m, "x>0 & x<=0.04"),
    proportion_externalreverts_5m.3medium=True(proportion_externalreverts_5m, "x>0.04 & x<=0.15"),

    proportion_revertedbyothers_5m.1zero=True(proportion_revertedbyothers_5m, "x==0"),
    proportion_revertedbyothers_5m.2low=True(proportion_revertedbyothers_5m, "x>0 & x<=0.02"),
    proportion_revertedbyothers_5m.3medium=True(proportion_revertedbyothers_5m, "x>0.02 & x<=0.1"),

    proportion_realcomments_5m.1zero=True(proportion_realcomments_5m, "x==0"),
    proportion_realcomments_5m.2low=True(proportion_realcomments_5m, "x>0 & x<=0.3"),
    proportion_realcomments_5m.3medium=True(proportion_realcomments_5m, "x>0.3 & x<=0.7"),
    proportion_realcomments_5m.4high=True(proportion_realcomments_5m, "x>0.7 & x<1"),

    proportion_extent_deletion_5m.1zero=True(proportion_extent_deletion_5m, "x==0"),
    proportion_extent_deletion_5m.2low=True(proportion_extent_deletion_5m, "x>0 & x<=0.1"),
    proportion_extent_deletion_5m.3medium=True(proportion_extent_deletion_5m, "x>0.1 & x<=0.49"),
    proportion_extent_deletion_5m.4high=True(proportion_extent_deletion_5m, "x>0.49 & x<1"),

    proportion_extent_word_5m.1zero=True(proportion_extent_word_5m, "x==0"),
    proportion_extent_word_5m.2low=True(proportion_extent_word_5m, "x>0 & x<=0.2"),
    proportion_extent_word_5m.3medium=True(proportion_extent_word_5m, "x>0.2 & x<=0.49"),
    proportion_extent_word_5m.4high=True(proportion_extent_word_5m, "x>0.49 & x<1"),

    proportion_extent_sentence_5m.1zero=True(proportion_extent_sentence_5m, "x==0"),
    proportion_extent_sentence_5m.2low=True(proportion_extent_sentence_5m, "x>0 & x<=0.2"),
    proportion_extent_sentence_5m.3medium=True(proportion_extent_sentence_5m, "x>0.2 & x<=0.51"),
    proportion_extent_sentence_5m.4high=True(proportion_extent_sentence_5m, "x>0.51 & x<1"),

    proportion_extent_paragraph_5m.1zero=True(proportion_extent_paragraph_5m, "x==0"),
    proportion_extent_paragraph_5m.2low=True(proportion_extent_paragraph_5m, "x>0 & x<=0.2"),
    proportion_extent_paragraph_5m.3high=True(proportion_extent_paragraph_5m, "x>0.2 & x<1"),

    number_edits_usertalk_2m.1zero=True(number_edits_usertalk_2m, "x==0"),

    extent_userpageedits_5m.1negative=True(extent_userpageedits_5m, "x < -30"),
    extent_userpageedits_5m.2zero=True(extent_userpageedits_5m, "x==0"),
    extent_userpageedits_5m.3moderate=True(extent_userpageedits_5m, "x > -30 & x!=0 & x<=1000"),

    days_between_first_previous.1zero=True(days_between_first_previous, "x==0"),
    days_between_first_previous.2seven=True(days_between_first_previous, "x>0 & x<=7"),
    days_between_first_previous.3sixty=True(days_between_first_previous, "x>7 & x<=60"),

    days_since_previous.1upto1=True(days_since_previous, "x>0 & x<=1"),
    days_since_previous.2upto2=True(days_since_previous, "x>1 & x<=2"),
    days_since_previous.3upto4=True(days_since_previous, "x>2 & x<=4"),
    days_since_previous.4upto7=True(days_since_previous, "x>4 & x<=7"),
    days_since_previous.5upto11=True(days_since_previous, "x>7 & x<=11"),
    days_since_previous.6upto17=True(days_since_previous, "x>11 & x<=17"),
    days_since_previous.7upto25=True(days_since_previous, "x>17 & x<=25"),
    days_since_previous.8upto36=True(days_since_previous, "x>25 & x<=36"),
    days_since_previous.9upto50=True(days_since_previous, "x>36 & x<=50"),
    days_since_previous.10upto75=True(days_since_previous, "50 & x<=75"),
    days_since_previous.11upto110=True(days_since_previous, "75 & x<=110"),

    has_userpage=True(has_userpage, "x==1"),
    edittime_gini_5m.1zero=True(edittime_gini, "x<=0.7"),
    edittime_gini_5m.2low=True(edittime_gini, "x>0.7 & x<=0.9"),
    edittime_gini_5m.3high=True(edittime_gini, "x>0.9 & x<=0.95")
  )
  
  
  einflussvariablen <- names(einfluss)[-1]
  verwende_nicht <- c(verwende_nicht, "number_edits_article_5m", "number_edits_articletalk_5m", "number_edits_user_5m", "number_edits_usertalk_5m", "number_edits_wikipediaboth_5m", "number_articles_5m", "number_extent_deletion_5m", "number_extent_word_5m", "number_extent_sentence_5m", "number_extent_paragraph_5m", "number_edits_5m","days_since_previous", "days_between_first_previous", "extent_userpageedits_5m", "number_edits_usertalk_2m", "proportion_extent_paragraph_5m", "proportion_extent_sentence_5m", "proportion_extent_word_5m", "proportion_extent_deletion_5m", "number_usertalkpages_5m", "proportion_articles_edits_5m", "proportion_edits_wikipediaboth_5m", "proportion_edits_usertalk_5m", "proportion_edits_user_5m", "proportion_edits_articletalk_5m", "proportion_edits_article_5m", "number_realcomments_5m", "proportion_realcomments_5m", "number_selfreverted_5m", "number_revertedbyothers_5m", "number_selfreverts_5m", "number_externalreverts_5m", "proportion_revertedbyothers_5m", "proportion_selfreverts_5m", "proportion_externalreverts_5m")
  verwende_nicht <- c(verwende_nicht)
  alle_wochenweise <- grep(pattern="_[0-9]+w", einflussvariablen, value=TRUE)
  verwende_nicht <- unique(c(verwende_nicht, alle_wochenweise, "number_edits_restlichereinschlusszeitraum", "number_edits_past", "number_edits_12m"))
  verwende <- unique(c(verwende, einflussvariablen[!(einflussvariablen %in% verwende_nicht)]))
  
  
  data <- einfluss[verwende]
  if(!is.null(ziel_zeitraum)) data <- cbind(data, ziel["solution"])
  

  neueinsteiger <- einfluss$number_edits_past==0
  nichteingeschlossene <- einfluss$number_edits_12m==0 #solche Leute w�rden sp�ter gar nicht in unserer Stichprobe auftauchen, interessieren uns also nicht
  pausierer <- (einfluss$number_edits_past!=0 & einfluss$number_edits_5m==0) & !nichteingeschlossene
  rest <- !(neueinsteiger | pausierer | nichteingeschlossene)
  
  if(schaetze.pausierer==0) pausierer.solution <- data.frame(user_id=einfluss$user_id[pausierer], solution=0)
  if(schaetze.pausierer==1){
        data.pausierer <- data.frame(user_id=einfluss$user_id, inactive_weeks=floor(einfluss$days_since_previous/7))[pausierer,]
        load(file="wiederkommer.schaetzung2.RData")
        pausierer.solution <- data.frame(user_id=data.pausierer["user_id"], solution=0)
        for(i in 22:45){
            abstinenz_inds <- which(data.pausierer["inactive_weeks"]==i)
            pausierer.solution$solution[abstinenz_inds] <- preds_abstinenz[as.character(i)]
        } 
  }
  result <- list(data=data[rest,], pausierer.solution=pausierer.solution, data.user_id=einfluss$user_id[rest])
  return(result)
}


datenvorverarbeitung2 <- function(einfluss_zeitraum="b", ziel_zeitraum=NULL, verwende=NULL, verwende_nicht=NULL, schaetze.pausierer=0){
  einfluss <- sqlQuery(wikidata, paste("SELECT * FROM wc.einfluss_", einfluss_zeitraum, sep=""))
  if(!is.null(ziel_zeitraum)) ziel <- sqlQuery(wikidata, paste("SELECT * FROM wc.ziel_", ziel_zeitraum, sep="")) 
  
  keepNA_1 <- is.na(einfluss[,"days_between_first_previous"])
  einfluss[is.na(einfluss)] <- 0
  einfluss[,"days_between_first_previous"][keepNA_1] <- NA 
  
  einfluss <- transform(einfluss,
    number_edits_5to2m=number_edits_5m-number_edits_2m,
    number_edits_12to5m=number_edits_12m-number_edits_5m,
    proportion_edits_article_5m=number_edits_article_5m/number_edits_5m,
    proportion_edits_articletalk_5m=number_edits_articletalk_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_user_5m=number_edits_user_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_usertalk_5m=number_edits_usertalk_5m/(number_edits_5m-number_edits_article_5m),
    proportion_edits_wikipediaboth_5m=number_edits_wikipediaboth_5m/(number_edits_5m-number_edits_article_5m),
    proportion_articles_edits_5m=number_articles_5m/number_edits_5m,
    proportion_selfreverts_5m=number_selfreverts_5m/number_edits_5m,
    proportion_externalreverts_5m=number_externalreverts_5m/number_edits_5m,
    proportion_revertedbyothers_5m=number_revertedbyothers_5m/number_edits_5m,
    proportion_extent_deletion_5m=number_extent_deletion_5m/number_edits_5m,
    proportion_extent_word_5m=number_extent_word_5m/number_edits_5m,
    proportion_extent_sentence_5m=number_extent_sentence_5m/number_edits_5m,
    proportion_extent_paragraph_5m=number_extent_paragraph_5m/number_edits_5m,
    proportion_realcomments_5m=number_realcomments_5m/number_edits_5m
  )
True <- function(x, cond, na.false=TRUE){
  result <- ifelse(eval(parse(text=cond)), TRUE, FALSE)
  if(na.false) result[is.na(result)] <- FALSE
  result <- factor(result, levels=c(TRUE, FALSE))
  return(result)
}

  einfluss <- transform(einfluss,
    proportion_edits_article_5m.1zero=True(proportion_edits_article_5m, "x==0"),
    proportion_edits_article_5m.2low=True(proportion_edits_article_5m, "x>0 & x<=0.7"),
    proportion_edits_article_5m.3high=True(proportion_edits_article_5m, "x>0.7 & x<1"),

    proportion_edits_articletalk_5m.1zero=True(proportion_edits_articletalk_5m, "x==0"),
    proportion_edits_articletalk_5m.2low=True(proportion_edits_articletalk_5m, "x>0 & x<=0.3"),
    proportion_edits_articletalk_5m.3high=True(proportion_edits_articletalk_5m, "x>0.3 & x<1"),

    proportion_edits_user_5m.1zero=True(proportion_edits_user_5m, "x==0"),
    proportion_edits_user_5m.2low=True(proportion_edits_user_5m, "x>0 & x<=0.2"),
    proportion_edits_user_5m.3high=True(proportion_edits_user_5m, "x>0.2 & x<1"),

    proportion_edits_usertalk_5m.1zero=True(proportion_edits_usertalk_5m, "x==0"),
    proportion_edits_usertalk_5m.2low=True(proportion_edits_usertalk_5m, "x>0 & x<=0.3"),
    proportion_edits_usertalk_5m.3high=True(proportion_edits_usertalk_5m, "x>0.3 & x< 1"),

    proportion_edits_wikipediaboth_5m.1zero=True(proportion_edits_wikipediaboth_5m, "x==0"),
    proportion_edits_wikipediaboth_5m.2low=True(proportion_edits_wikipediaboth_5m, "x>0 & x<=0.3"),
    proportion_edits_wikipediaboth_5m.3high=True(proportion_edits_wikipediaboth_5m, "x>0.3 & x< 1"),

    proportion_articles_edits_5m.1low=True(proportion_articles_edits_5m, "x>0 & x<=0.3"),
    proportion_articles_edits_5m.2high=True(proportion_articles_edits_5m, "x>0.3 & x<1"),

    number_usertalkpages_5m.1many=True(number_usertalkpages_5m, "x>2"),

    proportion_selfreverts_5m.1zero=True(proportion_selfreverts_5m, "x==0"),
    proportion_selfreverts_5m.2low=True(proportion_selfreverts_5m, "x>0 & x<=0.03"),

    proportion_externalreverts_5m.1zero=True(proportion_externalreverts_5m, "x==0"),
    proportion_externalreverts_5m.2low=True(proportion_externalreverts_5m, "x>0 & x<=0.04"),
    proportion_externalreverts_5m.3medium=True(proportion_externalreverts_5m, "x>0.04 & x<=0.15"),

    proportion_revertedbyothers_5m.1zero=True(proportion_revertedbyothers_5m, "x==0"),
    proportion_revertedbyothers_5m.2low=True(proportion_revertedbyothers_5m, "x>0 & x<=0.02"),
    proportion_revertedbyothers_5m.3medium=True(proportion_revertedbyothers_5m, "x>0.02 & x<=0.1"),

    proportion_realcomments_5m.1zero=True(proportion_realcomments_5m, "x==0"),
    proportion_realcomments_5m.2low=True(proportion_realcomments_5m, "x>0 & x<=0.3"),
    proportion_realcomments_5m.3medium=True(proportion_realcomments_5m, "x>0.3 & x<=0.7"),
    proportion_realcomments_5m.4high=True(proportion_realcomments_5m, "x>0.7 & x<1"),

    proportion_extent_deletion_5m.1zero=True(proportion_extent_deletion_5m, "x==0"),
    proportion_extent_deletion_5m.2low=True(proportion_extent_deletion_5m, "x>0 & x<=0.1"),
    proportion_extent_deletion_5m.3medium=True(proportion_extent_deletion_5m, "x>0.1 & x<=0.49"),
    proportion_extent_deletion_5m.4high=True(proportion_extent_deletion_5m, "x>0.49 & x<1"),

    proportion_extent_word_5m.1zero=True(proportion_extent_word_5m, "x==0"),
    proportion_extent_word_5m.2low=True(proportion_extent_word_5m, "x>0 & x<=0.2"),
    proportion_extent_word_5m.3medium=True(proportion_extent_word_5m, "x>0.2 & x<=0.49"),
    proportion_extent_word_5m.4high=True(proportion_extent_word_5m, "x>0.49 & x<1"),

    proportion_extent_sentence_5m.1zero=True(proportion_extent_sentence_5m, "x==0"),
    proportion_extent_sentence_5m.2low=True(proportion_extent_sentence_5m, "x>0 & x<=0.2"),
    proportion_extent_sentence_5m.3medium=True(proportion_extent_sentence_5m, "x>0.2 & x<=0.51"),
    proportion_extent_sentence_5m.4high=True(proportion_extent_sentence_5m, "x>0.51 & x<1"),

    proportion_extent_paragraph_5m.1zero=True(proportion_extent_paragraph_5m, "x==0"),
    proportion_extent_paragraph_5m.2low=True(proportion_extent_paragraph_5m, "x>0 & x<=0.2"),
    proportion_extent_paragraph_5m.3high=True(proportion_extent_paragraph_5m, "x>0.2 & x<1"),

    number_edits_usertalk_2m.1zero=True(number_edits_usertalk_2m, "x==0"),

    extent_userpageedits_5m.1negative=True(extent_userpageedits_5m, "x < -30"),
    extent_userpageedits_5m.2zero=True(extent_userpageedits_5m, "x==0"),
    extent_userpageedits_5m.3moderate=True(extent_userpageedits_5m, "x > -30 & x!=0 & x<=1000"),

    days_between_first_previous.1zero=True(days_between_first_previous, "x==0"),
    days_between_first_previous.2seven=True(days_between_first_previous, "x>0 & x<=7"),
    days_between_first_previous.3sixty=True(days_between_first_previous, "x>7 & x<=60"),

    days_since_previous.1upto1=True(days_since_previous, "x>0 & x<=1"),
    days_since_previous.2upto2=True(days_since_previous, "x>1 & x<=2"),
    days_since_previous.3upto4=True(days_since_previous, "x>2 & x<=4"),
    days_since_previous.4upto7=True(days_since_previous, "x>4 & x<=7"),
    days_since_previous.5upto11=True(days_since_previous, "x>7 & x<=11"),
    days_since_previous.6upto17=True(days_since_previous, "x>11 & x<=17"),
    days_since_previous.7upto25=True(days_since_previous, "x>17 & x<=25"),
    days_since_previous.8upto36=True(days_since_previous, "x>25 & x<=36"),
    days_since_previous.9upto50=True(days_since_previous, "x>36 & x<=50"),
    days_since_previous.10upto75=True(days_since_previous, "50 & x<=75"),
    days_since_previous.11upto110=True(days_since_previous, "75 & x<=110")
  )
  
  
  einflussvariablen <- names(einfluss)[-1]
  verwende_nicht <- c(verwende_nicht, "number_edits_article_5m", "number_edits_articletalk_5m", "number_edits_user_5m", "number_edits_usertalk_5m", "number_edits_wikipediaboth_5m", "number_articles_5m", "number_extent_deletion_5m", "number_extent_word_5m", "number_extent_sentence_5m", "number_extent_paragraph_5m", "number_edits_5m","days_since_previous", "days_between_first_previous", "extent_userpageedits_5m", "number_edits_usertalk_2m", "proportion_extent_paragraph_5m", "proportion_extent_sentence_5m", "proportion_extent_word_5m", "proportion_extent_deletion_5m", "number_usertalkpages_5m", "proportion_articles_edits_5m", "proportion_edits_wikipediaboth_5m", "proportion_edits_usertalk_5m", "proportion_edits_user_5m", "proportion_edits_articletalk_5m", "proportion_edits_article_5m", "number_realcomments_5m", "proportion_realcomments_5m", "number_selfreverted_5m", "number_revertedbyothers_5m", "number_selfreverts_5m", "number_externalreverts_5m", "proportion_revertedbyothers_5m", "proportion_selfreverts_5m", "proportion_externalreverts_5m")
  verwende_nicht <- c(verwende_nicht)
  alle_wochenweise <- grep(pattern="_[0-9]+w", einflussvariablen, value=TRUE)
  verwende_nicht <- unique(c(verwende_nicht, alle_wochenweise, "number_edits_restlichereinschlusszeitraum", "number_edits_past", "number_edits_12m"))
  verwende <- unique(c(verwende, einflussvariablen[!(einflussvariablen %in% verwende_nicht)]))
  
  
  data <- einfluss[verwende]
  if(!is.null(ziel_zeitraum)) data <- cbind(data, ziel["solution"])
  

  neueinsteiger <- einfluss$number_edits_past==0
  nichteingeschlossene <- einfluss$number_edits_12m==0 #solche Leute w�rden sp�ter gar nicht in unserer Stichprobe auftauchen, interessieren uns also nicht
  pausierer <- (einfluss$number_edits_past!=0 & einfluss$number_edits_5m==0) & !nichteingeschlossene
  rest <- !(neueinsteiger | pausierer | nichteingeschlossene)
  
  if(schaetze.pausierer==0) pausierer.solution <- data.frame(user_id=einfluss$user_id[pausierer], solution=0)
  if(schaetze.pausierer==1){
        data.pausierer <- data.frame(user_id=einfluss$user_id, inactive_weeks=floor(einfluss$days_since_previous/7))[pausierer,]
        load(file="wiederkommer.schaetzung2.RData")
        pausierer.solution <- data.frame(user_id=data.pausierer["user_id"], solution=0)
        for(i in 22:45){
            abstinenz_inds <- which(data.pausierer["inactive_weeks"]==i)
            pausierer.solution$solution[abstinenz_inds] <- preds_abstinenz[as.character(i)]
        } 
  }
  result <- list(data=data[rest,], pausierer.solution=pausierer.solution, data.user_id=einfluss$user_id[rest])
  return(result)
}
