------------
-- Users  --
------------

/* DROP TABLE IF EXISTS wc.users; */
CREATE TABLE wc.users
  SELECT DISTINCT user_id
  FROM wcraw.training;



---------------------
-- Target variable --
---------------------

-- ziel_b
SET @start_date = '20100401000000';
/* DROP TABLE IF EXISTS wc.ziel_b; */
CREATE TABLE wc.ziel_b
  SELECT *
    FROM wc.users LEFT JOIN
      (SELECT user_id, COUNT(*) AS solution
        FROM wcraw.training
        WHERE timestamp>=@start_date AND timestamp<ADDDATE(@start_date, INTERVAL 5 MONTH)
        GROUP BY user_id)
      AS ziel USING (user_id);
/* Dauer: etwa 90 s */
UPDATE wc.ziel_b
  SET
    solution = IF(ISNULL(solution), 0, solution);

-- ziel_c
SET @start_date = '20091101000000';
/* DROP TABLE IF EXISTS wc.ziel_c; */
CREATE TABLE wc.ziel_c
  SELECT *
    FROM wc.users LEFT JOIN
      (SELECT user_id, COUNT(*) AS solution
        FROM wcraw.training
        WHERE timestamp>=@start_date AND timestamp<ADDDATE(@start_date, INTERVAL 5 MONTH)
        GROUP BY user_id)
      AS ziel USING (user_id);
/* Dauer: etwa 80 s */
UPDATE wc.ziel_c
  SET
    solution = IF(ISNULL(solution), 0, solution);



------------------------------------------
-- Empty tables for predictor variables --
------------------------------------------

-- einfluss_a
/* DROP TABLE IF EXISTS wc.einfluss_a; */
CREATE TABLE wc.einfluss_a
  SELECT *
    FROM wc.users;

-- einfluss_b
/* DROP TABLE IF EXISTS wc.einfluss_b; */
CREATE TABLE wc.einfluss_b
  SELECT *
    FROM wc.users;

-- einfluss_c
/* DROP TABLE IF EXISTS wc.einfluss_c; */
CREATE TABLE wc.einfluss_c
  SELECT *
    FROM wc.users;



-----------------------------------------------
-- Procedures for adding predictor variables --
-----------------------------------------------

-- Procedure for adding new variables to one existing table
/* 
toTable - name of the existing table
sqlStmNewVar - SQL call providing table (user_id,new_var_1, new_var_2, ...)
*/
DROP PROCEDURE IF EXISTS wc.addvartotable;
DELIMITER //
CREATE PROCEDURE wc.addvartotable(IN toTable VARCHAR(25), IN sqlStmNewVar TEXT, IN end_date DATETIME)
BEGIN
/* Random M5 checksum to be used as a name of a temporary table, e.g. 9447add6a5f2a070658cfb11d235d770 */
SET @tmp_table_name = MD5(RAND());
/* Generating a temporary table as a join of the existing table and the new variables*/
SET @dynsql_temp_result = CONCAT ('CREATE TEMPORARY TABLE ',@tmp_table_name, ' SELECT * FROM ',toTable, ' LEFT JOIN (', sqlStmNewVar,') AS einfluss USING (user_id);');
/* If an end_date wants to be used in this call it has to be denoted by '#' */
SET @dynsql_temp_result = REPLACE(@dynsql_temp_result, '#', end_date);
/* Drop old table */
SET @dynsql_drop_old = CONCAT('DROP TABLE IF EXISTS ',toTable);
 /* Create temporary table with the name of the old table */
SET @dynsql_temp_to_result = CONCAT('CREATE TABLE ', toTable, ' SELECT * FROM ', @tmp_table_name);
/* Drop temporary table */
SET @del_temp_table = CONCAT('DROP TABLE ', @tmp_table_name);
/* Execute aboves SQL statements */
PREPARE s1 FROM @dynsql_temp_result;
EXECUTE s1;
PREPARE s1 FROM @dynsql_drop_old;
EXECUTE s1;
PREPARE s1 FROM @dynsql_temp_to_result;
EXECUTE s1;
PREPARE s1 FROM @del_temp_table;
EXECUTE s1;     
END//
DELIMITER ;

-- Procedure for adding new variables to all three tables
/*
sqlStmNewVar - SQL call generating user-based statistics in a table of structure (user_id, new_var_1, new_var_2, ...)
*/
DROP PROCEDURE IF EXISTS wc.gen_new_var;
DELIMITER //
CREATE PROCEDURE wc.gen_new_var(IN sqlStmNewVar TEXT)
BEGIN
SET @sql_einfluss_a = CONCAT('CALL wc.addvartotable(\'wc.einfluss_a\',\'', sqlStmNewVar, '\',\'2010-09-01\')');
SET @sql_einfluss_b = CONCAT('CALL wc.addvartotable(\'wc.einfluss_b\',\'', sqlStmNewVar, '\',\'2010-04-01\')');
SET @sql_einfluss_c = CONCAT('CALL wc.addvartotable(\'wc.einfluss_c\',\'', sqlStmNewVar, '\',\'2009-11-01\')');
PREPARE stm1 FROM @sql_einfluss_a;
PREPARE stm2 FROM @sql_einfluss_b;
PREPARE stm3 FROM @sql_einfluss_c;
EXECUTE stm1;
EXECUTE stm2;
EXECUTE stm3;
END
//
DELIMITER ;




----------------------
-- Auxiliary tables --
----------------------

-- Userpages
/* try to match userpages to users */
/*
CREATE TABLE wc.userpages
  SELECT user_id,
      article_id AS userpage
    FROM wcraw.training             
    WHERE namespace=2
    GROUP BY user_id;
*/

-- Comments
CREATE TABLE wc.userid_and_comments
  SELECT training.user_id, training.revision_id, training.timestamp, comments.comment
    FROM wcraw.training LEFT JOIN wcraw.comments USING(revision_id);
CREATE TABLE wc.userid_and_realcomments
  SELECT user_id, timestamp,
      IF(comment NOT REGEXP '^/\\*.*\\*/$',1,0) AS is_realcomment  
    FROM wc.userid_and_comments;

-- Reverts
CREATE TABLE wc.revauszug SELECT user_id, revision_id, article_id, timestamp, reverted_revision_id FROM wcraw.training WHERE reverted=1 AND revision_id=283479151;
/*CREATE TABLE wc.revertededits2 AS  */
  SELECT revisiontable.user_id AS user_id_reverted, reverttable.user_id AS user_id_reverting, reverttable.article_id AS article_id, revisiontable.timestamp AS timestamp_edit, reverttable.timestamp AS timestamp_revert
  , revisiontable.revision_id AS revisiontable_revision_id, reverttable.revision_id AS reverttable_revision_id, reverttable.reverted_revision_id AS reverttable_reverted_revision_id
   FROM wc.revauszug AS reverttable LEFT JOIN wcraw.training AS revisiontable ON revisiontable.article_id=reverttable.article_id WHERE revisiontable.revision_id < reverttable.revision_id AND revisiontable.revision_id > reverttable.reverted_revision_id; 

/*  
SELECT * FROM wc.revauszug;
SELECT SUM(reverted=1) FROM wcraw.training;
*/ 




/* Try a new variable: */
/*
SET @end_date = '2010-09-01';
SELECT user_id,
      COUNT(DISTINCT DATE(timestamp)) AS number_active_days_5m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE(@end_date, INTERVAL -22 WEEK) AND timestamp < @end_date
    GROUP BY user_id LIMIT 10, 10;
*/    
    


----------------------------------
-- Generate predictor variables --
----------------------------------

-- Variables based on the previous 2 months:

CALL wc.gen_new_var('
  SELECT user_id,
      COUNT(*) AS number_edits_2m,
      SUM(namespace=3) AS number_edits_usertalk_2m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL -8 WEEK) AND timestamp < "#"
    GROUP BY user_id
');
/* duration: about 2 min 10 sec */

-- Variables based on the previous 5 months:
/*
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(DISTINCT DATE(timestamp)) AS number_active_days_5m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp < "#"
    GROUP BY user_id
');
*/

CALL wc.gen_new_var('
  SELECT user_id,
      COUNT(*) AS number_edits_5m,
      SUM(namespace=0) AS number_edits_article_5m,
      SUM(namespace=1) AS number_edits_articletalk_5m,
      SUM(namespace=2) AS number_edits_user_5m,
      SUM(namespace=3) AS number_edits_usertalk_5m,
      SUM(namespace=4 OR namespace=5) AS number_edits_wikipediaboth_5m,
      COUNT(DISTINCT article_id) AS number_articles_5m,
      SUM((namespace=2)*delta) AS extent_userpageedits_5m,
      SUM(delta<-10) AS number_extent_deletion_5m,
      SUM(delta>=-10 AND delta<30) AS number_extent_word_5m,
      SUM(delta>=30 AND delta<300) AS number_extent_sentence_5m,
      SUM(delta>=300) AS number_extent_paragraph_5m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp < "#"
    GROUP BY user_id
');
/* duration: about 5 min 20 sec */

CALL wc.gen_new_var('
 SELECT user_id,
      COUNT(DISTINCT article_id) AS number_usertalkpages_5m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp < "#" AND namespace=3
    GROUP BY user_id
');
/* duration: about 50 sec */

CALL wc.gen_new_var('
  SELECT user_id_reverted AS user_id,
      SUM(user_id_reverted!=user_id_reverting) AS number_revertedbyothers_5m,
      SUM(user_id_reverted=user_id_reverting) AS number_selfreverted_5m   
    FROM wc.revertededits
    WHERE timestamp_edit >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp_edit < "#"
    GROUP BY user_id_reverted  
');
/* duration: about 50 sec */

CALL wc.gen_new_var('
  SELECT user_id_reverting AS user_id,
      SUM(user_id_reverted=user_id_reverting) AS number_selfreverts_5m, 
      SUM(user_id_reverted!=user_id_reverting) AS number_externalreverts_5m   
    FROM wc.revertededits
    WHERE timestamp_revert >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp_revert < "#"
    GROUP BY user_id_reverting  
');
/* duration: about 40 sec */

CALL wc.gen_new_var('
 SELECT user_id, 
    SUM(is_realcomment) AS number_realcomments_5m
  FROM wc.userid_and_realcomments
  WHERE timestamp >= ADDDATE("#", INTERVAL -22 WEEK) AND timestamp < "#"
  GROUP BY user_id 
');
/* duration: about 3 min 30 sec */


-- Variables based on the previous 12 months:

CALL wc.gen_new_var('
  SELECT user_id,
      COUNT(*) AS number_edits_12m
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL -12 MONTH) AND timestamp < "#"
    GROUP BY user_id
');
/* duration: about 5 min */



-- Variables based on the complete past:
CALL wc.gen_new_var('
  SELECT user_id,
      DATEDIFF(MAX(timestamp), MIN(timestamp)) AS days_between_first_previous,
      DATEDIFF("#", MAX(timestamp)) AS days_since_previous,
      SUM(namespace=2)>0 AS has_userpage,
      COUNT(*) AS number_edits_past
    FROM wcraw.training
    WHERE timestamp < "#"
    GROUP BY user_id
');
/* duration: about 6 min 30 sec sec */


-- Variables based on the complete past after 1 September 2009:
CALL wc.gen_new_var('
  SELECT user_id,
      COUNT(*) AS number_edits_restlichereinschlusszeitraum
    FROM wcraw.training
    WHERE timestamp >= "20090901000000" AND timestamp < "#"
    GROUP BY user_id
');
/* duration: about 4 min 30 sec */


-- Variables based on the i-th previous week:

SET @weeks_before = 1;    
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_1w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 2;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_2w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 3;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_3w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 4;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_4w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 5;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_5w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 6;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_6w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 7;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_7w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 8;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_8w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 9;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_9w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 10;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_10w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 11;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_11w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');
SET @weeks_before = 12;
CALL wc.gen_new_var('
SELECT user_id,
      COUNT(*) AS number_edits_12w
    FROM wcraw.training
    WHERE timestamp >= ADDDATE("#", INTERVAL (-@weeks_before) WEEK) AND timestamp < ADDDATE("#", INTERVAL (-@weeks_before + 1) WEEK)
    GROUP BY user_id
');

