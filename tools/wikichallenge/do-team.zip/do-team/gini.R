#install.packages("reldist")
library(reldist)
library(RODBC)

source("Edits_pro_Zeiteinheit.R")
source("datenvorverarbeitung.R")

#get connection
wikidata <- odbcConnect(dsn="wikidata")

#look by weeks in and use data from the whole time for einfluss_a/b/c 
unterteilung <- 86400*7
betrachteterZeitraum <- "MAX"

#get all user_ids
einfluss <- sqlQuery(wikidata, paste("SELECT * FROM wc.einfluss_", "a", sep=""))
user_ids <- einfluss$user_id

###############################################
#preprocess
dataa.list <- datenvorverarbeitung2(einfluss_zeitraum="a", ziel_zeitraum="a", verwende=NULL, verwende_nicht=NULL)
#set start and end of the five months (see tuning)
start.datum <- strptime("2010-03-31 00:00:00", format="%Y-%m-%d %H:%M:%S")
ende.datum <- strptime("2010-09-01 00:00:00", format="%Y-%m-%d %H:%M:%S")
#how many weeks do we have in the 5 months?
anzahl_shiftsa <- as.integer(ceiling(difftime(ende.datum, start.datum, units = "secs")/unterteilung))
#look at all of them (see Edits_pro_Zeiteinheit.R)
betrachteterZeitrauma <- 1:anzahl_shiftsa

#count the edits per week per active user 
revsa <- count.each.user.nedits(betrachteterZeitrauma)
#get all active ids
all.active.usersa <- unique(unlist(sapply(revsa, function(one.week) one.week$user_id))) #knapp 30k
#get the edits per week for all users
active.users.weeksa <-sapply(all.active.usersa, function(user_id) {
    sapply(revsa, function(one.week){
        if(!(user_id %in% one.week$user_id)) return(0)
        else return(one.week$edits[one.week$user_id==user_id])
    })
})

active.users.weeksa <- t(active.users.weeksa)
#compute gini coefficient for active
gini.active.usersa <- apply(active.users.weeksa, 1, gini)
#for all
edittime_gini.a <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersa)) return(0)
    else{
        id.pos <- which(all.active.usersa==user_id)
        return(gini.active.usersa[id.pos])
    }
    
})

###############################################     same for b
datab.list <- datenvorverarbeitung2(einfluss_zeitraum="b", ziel_zeitraum="b", verwende=NULL, verwende_nicht=NULL)
start.datum <- strptime("2009-10-29 00:00:00", format="%Y-%m-%d %H:%M:%S")
ende.datum <- strptime("2010-04-1 00:00:00", format="%Y-%m-%d %H:%M:%S")
anzahl_shiftsb <- as.integer(ceiling(difftime(ende.datum, start.datum, units = "secs")/unterteilung))
betrachteterZeitraumb <- 1:anzahl_shiftsb

revsb <- count.each.user.nedits(betrachteterZeitraumb)

all.active.usersb <- unique(unlist(sapply(revsb, function(one.week) one.week$user_id))) #knapp 30k
active.users.weeksb <-sapply(all.active.usersb, function(user_id) {
    sapply(revsb, function(one.week){
        if(!(user_id %in% one.week$user_id)) return(0)
        else return(one.week$edits[one.week$user_id==user_id])
    })
})

active.users.weeksb <- t(active.users.weeksb)
gini.active.usersb <- apply(active.users.weeksb, 1, gini)

edittime_gini.b <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersb)) return(0)
    else{
        id.pos <- which(all.active.usersb==user_id)
        return(gini.active.usersb[id.pos])
    }
    
})
########################################################### same for c
datab.list <- datenvorverarbeitung2(einfluss_zeitraum="b", ziel_zeitraum="b", verwende=NULL, verwende_nicht=NULL)
start.datum <- strptime("2009-05-31 00:00:00", format="%Y-%m-%d %H:%M:%S")
ende.datum <- strptime("2009-11-01 00:00:00", format="%Y-%m-%d %H:%M:%S")
anzahl_shiftsc <- as.integer(ceiling(difftime(ende.datum, start.datum, units = "secs")/unterteilung))
betrachteterZeitraumc <- 1:anzahl_shiftsc

revsc <- count.each.user.nedits(betrachteterZeitraumc)

all.active.usersc <- unique(unlist(sapply(revsc, function(one.week) one.week$user_id))) #knapp 30k
active.users.weeksc <-sapply(all.active.usersc, function(user_id) {
    sapply(revsc, function(one.week){
        if(!(user_id %in% one.week$user_id)) return(0)
        else return(one.week$edits[one.week$user_id==user_id])
    })
})

active.users.weeksc <- t(active.users.weeksc)
gini.active.usersc <- apply(active.users.weeksc, 1, gini)

edittime_gini.c <-sapply(user_ids, function(user_id){
    if(!(user_id %in% all.active.usersc)) return(0)
    else{
        id.pos <- which(all.active.usersc==user_id)
        return(gini.active.usersc[id.pos])
    }
    
})


save(edittime_gini.a, edittime_gini.b, edittime_gini.c, file="edittime_gini.RData")
