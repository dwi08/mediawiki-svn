#generate sql syntax for:

# for the week start.datum + (i-1)*unterteilung:
# get the number of edits in this week for each user active here

get_command <- function(start.datum, ende.datum, i){
    paste(
        "SELECT user_id, COUNT(*) AS edits, timestamp ", 
        "FROM wcraw.training ",
        "WHERE timestamp >= '", start.datum + (unterteilung)*(i-1) , "' AND timestamp < '", start.datum + (unterteilung)*(i),
        "' GROUP BY user_id ORDER BY timestamp", sep = "")
}

#wrapper for get_command; apply on weeks betrachteterZeitraum

count.each.user.nedits <- function(betrachteterZeitraum){
revs <- vector("list", length(betrachteterZeitraum))
    for (i in betrachteterZeitraum) {
       revs[[i]] <- sqlQuery(wikidata, get_command(start.datum, ende.datum, i))
        print(i)
    }
revs
}
    
