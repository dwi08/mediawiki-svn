
### select the folder, where you put our data
setwd(choose.dir())

### package installation
install.packages("mlr_0.3.2194.zip", repos=NULL)
library(mlr)

### load our datasets we created in datenvorverarbeitung.r
load("wikidata.RData")
dataa <- datalista$data
datab <- datalistb$data

### use logarithmic function on the solution vector
datab$solution <- log(datab$solution+1)

### create the learner we used in our final submission
learner <- makeLearner("regr.gbm",
			distribution="gaussian",
			n.trees=2000,
 			interaction.depth=4 ,
			shrinkage=0.004,
 			bag.fraction=0.1,
 			n.minobsinnode=10)


### create a task
taskb <- makeRegrTask(target="solution", data=datab)

### train data
model <- train(learner, task=taskb)

### predict data
pred <- predict(model, newdata=dataa)

### retransformation
preddf <- exp(pred@df$response)-1

### we adjust our predictions closer to zero
preddf[which(preddf<=1.44)] <- 0.32

### put user.ids and predictions together
prediction1 <- data.frame(datalista$data.user_id,preddf)
colnames(prediction1) <- c("user_id", "solution")

### our submission for not-pausing users
prediction1

### load prediction for pausing users
load("pausierer_neu.RData")
colnames(pliste.neu) <- c("user_id", "solution")
### merge both predictions and order by user id

submission <- rbind(pliste.neu, prediction1)
submission <- submission[order(submission$user_id), ]

write.table(submission, file="submission_final2.csv", 
            sep=",", col.names=TRUE, row.names=FALSE, quote=FALSE)



